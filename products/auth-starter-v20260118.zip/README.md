# Auth Starter (Supabase)

Production-ready authentication with Supabase

## Contents
- packages/antigravity

## Installation
1. Extract this archive
2. Follow the included documentation

---
Built with 🏯 AgencyOS
Version: 20260118
