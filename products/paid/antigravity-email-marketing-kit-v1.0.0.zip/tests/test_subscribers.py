import pytest

@pytest.mark.asyncio
async def test_create_mailing_list(client):
    response = await client.post("/api/v1/subscribers/lists/", json={
        "name": "Test List",
        "description": "A list for testing"
    })
    assert response.status_code == 200
    data = response.json()
    assert data["name"] == "Test List"
    assert "id" in data

@pytest.mark.asyncio
async def test_create_subscriber(client):
    # First create a list
    list_res = await client.post("/api/v1/subscribers/lists/", json={"name": "News"})
    list_id = list_res.json()["id"]

    # Create subscriber
    response = await client.post("/api/v1/subscribers/subscribers/", json={
        "email": "john@example.com",
        "first_name": "John",
        "list_ids": [list_id]
    })
    assert response.status_code == 200
    data = response.json()
    assert data["email"] == "john@example.com"
    assert data["status"] == "unconfirmed"
    assert len(data["lists"]) == 1
    assert data["lists"][0]["id"] == list_id

@pytest.mark.asyncio
async def test_unsubscribe(client):
    # Create subscriber
    sub_res = await client.post("/api/v1/subscribers/subscribers/", json={
        "email": "leaver@example.com"
    })
    sub_id = sub_res.json()["id"]

    # Unsubscribe
    response = await client.get(f"/api/v1/subscribers/{sub_id}/unsubscribe")
    assert response.status_code == 200
    assert "You have been unsubscribed" in response.text
