import SettingsPage from "@/pages/settings"

export default function Page() {
  return <SettingsPage />
}
