import DashboardPage from "@/pages/dashboard"

export default function Page() {
  return <DashboardPage />
}
