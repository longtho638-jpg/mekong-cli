import DashboardPage from "@/pages/dashboard"

export default function Home() {
  return <DashboardPage />
}
