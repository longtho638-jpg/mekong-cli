import UsersPage from "@/pages/users"

export default function Page() {
  return <UsersPage />
}
