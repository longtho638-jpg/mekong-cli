import AnalyticsPage from "@/pages/analytics"

export default function Page() {
  return <AnalyticsPage />
}
