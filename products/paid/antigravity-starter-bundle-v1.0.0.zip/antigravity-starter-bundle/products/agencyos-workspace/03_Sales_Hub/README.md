# Sales Hub (03)
**"The Wallet"** - Focus on Leads and Deals.

## Subdirectories
- **CRM/**: Lead lists and deal tracking.
- **Proposals/**: Draft and sent proposals.
- **Contracts/**: Client agreements.

## Responsible Agent
**Sales Closer** (sales-closer.md)
