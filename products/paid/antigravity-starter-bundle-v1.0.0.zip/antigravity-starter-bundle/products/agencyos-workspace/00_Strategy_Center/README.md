# Strategy Center (00)
**"The Brain"** - Focus on Vision, Strategy, and Legal.

## Subdirectories
- **OKR/**: Quarterly Objectives and Key Results.
- **Brand_Identity/**: Mission, Vision, Values, Voice Guidelines.
- **Legal/**: Contracts, Compliance, Corporate Docs.

## Responsible Agent
**Strategy Director** (strategy-director.md)
