# System Core (.antigravity)
This directory contains the "Brain" of your AgencyOS.
- **agents/**: Your AI digital staff definitions.
- **skills/**: Specialized knowledge and tools for your agents.

**DO NOT MODIFY** unless you are customizing the AI behavior.
