# Planning

## Description
Skill for planning operations.

## When to Use
Use when working with planning related tasks.

## Implementation
Located in implementation.py or scripts/ directory.

## Dependencies
Check requirements.txt for Python dependencies.
Check package.json for Node.js dependencies.
