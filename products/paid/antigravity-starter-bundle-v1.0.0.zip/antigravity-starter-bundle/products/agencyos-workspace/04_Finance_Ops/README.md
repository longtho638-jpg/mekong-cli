# Finance Ops (04)
**"The Scoreboard"** - Focus on Money and Metrics.

## Subdirectories
- **Invoices/**: Incoming and outgoing bills.
- **Expenses/**: Receipts and tracking.
- **Reports/**: P&L, Cashflow, Projections.

## Responsible Agent
**Finance Controller** (finance-controller.md)
