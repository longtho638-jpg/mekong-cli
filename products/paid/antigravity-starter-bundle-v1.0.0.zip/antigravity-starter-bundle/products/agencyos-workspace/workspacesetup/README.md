# Workspace Setup
Contains installation scripts and configuration guides.

See root `README_OPS.md` for the main user manual.
