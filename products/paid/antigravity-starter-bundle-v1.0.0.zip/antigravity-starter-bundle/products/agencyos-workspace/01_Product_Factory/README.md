# Product Factory (01)
**"The Hands"** - Focus on Delivery and Execution.

## Subdirectories
- **Projects/**: Client project folders (Active/Archived).
- **Delivery_SOPs/**: How-to guides for your team.

## Responsible Agent
**Product Manager** (product-manager.md)
