# Agent Workflows (.agent)
This directory stores your Standard Operating Procedures (SOPs) as AI-readable templates.
- **workflows/**: Markdown templates for tasks like QBRs, Proposals, and Sprint Planning.

Your agents read these files to know EXACTLY how to execute tasks.
