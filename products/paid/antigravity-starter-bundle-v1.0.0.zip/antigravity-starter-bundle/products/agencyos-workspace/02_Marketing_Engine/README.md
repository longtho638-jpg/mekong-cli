# Marketing Engine (02)
**"The Voice"** - Focus on Content and Visibility.

## Subdirectories
- **Content_Calendar/**: Weekly/Monthly content plans.
- **Assets/**: Images, Videos, Templates.

## Responsible Agent
**Marketing Wizard** (marketing-wizard.md)
