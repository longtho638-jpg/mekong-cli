// Re-export hook from AuthProvider for consistency
export { useAuth } from '../components/auth/auth-provider';
