// Re-export client creator for convenience
export { createClient } from '../lib/supabase-client';
