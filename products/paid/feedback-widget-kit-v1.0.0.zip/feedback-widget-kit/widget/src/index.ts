export { FeedbackWidget } from './components/FeedbackWidget';
export { useFeedback } from './hooks/useFeedback';
export type { FeedbackData, FeedbackWidgetProps } from './components/FeedbackWidget';
