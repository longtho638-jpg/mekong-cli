# Global Redis client placeholder
redis_client = None
