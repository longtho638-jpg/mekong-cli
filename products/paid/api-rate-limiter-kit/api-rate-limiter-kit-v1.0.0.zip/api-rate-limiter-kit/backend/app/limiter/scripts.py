# Fixed Window Counter
# KEYS[1]: The rate limit key (e.g., "rate_limit:ip:127.0.0.1")
# ARGV[1]: Window size in seconds (ttl)
# ARGV[2]: Limit count
# Returns: {allowed (1/0), current_count, ttl}

FIXED_WINDOW_SCRIPT = """
local key = KEYS[1]
local window = tonumber(ARGV[1])
local limit = tonumber(ARGV[2])

local current = redis.call("INCR", key)

if current == 1 then
    redis.call("EXPIRE", key, window)
end

local ttl = redis.call("TTL", key)

if current > limit then
    return {0, current, ttl}
else
    return {1, current, ttl}
end
"""

# Sliding Window Log (ZSET)
# KEYS[1]: The rate limit key
# ARGV[1]: Current timestamp (score)
# ARGV[2]: Window size in seconds
# ARGV[3]: Limit count
# ARGV[4]: Unique member identifier (usually timestamp + random)
# Returns: {allowed (1/0), current_count, ttl}

SLIDING_WINDOW_SCRIPT = """
local key = KEYS[1]
local now = tonumber(ARGV[1])
local window = tonumber(ARGV[2])
local limit = tonumber(ARGV[3])
local member = ARGV[4]

local clear_before = now - window

-- Remove old entries
redis.call("ZREMRANGEBYSCORE", key, "-inf", clear_before)

-- Count current
local count = redis.call("ZCARD", key)

if count < limit then
    -- Add new request
    redis.call("ZADD", key, now, member)
    redis.call("EXPIRE", key, window)
    return {1, count + 1, window}
else
    -- Blocked
    local ttl = redis.call("TTL", key)
    return {0, count, ttl}
end
"""

# Token Bucket
# KEYS[1]: The rate limit key
# ARGV[1]: Rate (tokens per second) - derived from limit/window
# ARGV[2]: Capacity (max burst) - usually equals limit
# ARGV[3]: Current timestamp (seconds)
# ARGV[4]: Requested tokens (default 1)
# Returns: {allowed (1/0), remaining_tokens, retry_after}

TOKEN_BUCKET_SCRIPT = """
local key = KEYS[1]
local rate = tonumber(ARGV[1])
local capacity = tonumber(ARGV[2])
local now = tonumber(ARGV[3])
local requested = tonumber(ARGV[4])

local last_updated_key = key .. ":ts"
local tokens_key = key .. ":tokens"

local last_updated = tonumber(redis.call("GET", last_updated_key))
local current_tokens = tonumber(redis.call("GET", tokens_key))

if last_updated == nil then
    current_tokens = capacity
    last_updated = now
end

local delta = math.max(0, now - last_updated)
local filled_tokens = math.min(capacity, current_tokens + (delta * rate))

local allowed = 0
local remaining = filled_tokens
local retry_after = 0

if filled_tokens >= requested then
    allowed = 1
    remaining = filled_tokens - requested
    redis.call("SET", tokens_key, remaining)
    redis.call("SET", last_updated_key, now)

    -- Set expiry to avoid stale keys (e.g., 1 hour or based on refill time)
    redis.call("EXPIRE", tokens_key, 3600)
    redis.call("EXPIRE", last_updated_key, 3600)
else
    allowed = 0
    remaining = filled_tokens
    local needed = requested - filled_tokens
    if rate > 0 then
        retry_after = needed / rate
    else
        retry_after = 3600 -- Arbitrary long time if rate is 0
    end
end

return {allowed, remaining, retry_after}
"""
