from pydantic import BaseModel
from typing import Optional, Dict, Any
from datetime import datetime

class NotificationBase(BaseModel):
    user_id: str
    type: str
    title: str
    body: str
    data: Optional[Dict[str, Any]] = None

class NotificationCreate(NotificationBase):
    pass

class NotificationUpdate(BaseModel):
    is_read: bool

class Notification(NotificationBase):
    id: int
    is_read: bool
    created_at: datetime

    class Config:
        from_attributes = True

class PreferenceBase(BaseModel):
    user_id: str
    type: str
    channel: str
    enabled: bool

class PreferenceCreate(PreferenceBase):
    pass

class Preference(PreferenceBase):
    id: int

    class Config:
        from_attributes = True
