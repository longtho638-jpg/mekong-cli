import pytest
from unittest.mock import MagicMock, patch
import httpx
from app.core.webhook_client import WebhookClient

@pytest.mark.asyncio
async def test_webhook_success():
    client = WebhookClient()
    with patch.object(client.client, 'post', new_callable=MagicMock) as mock_post:
        mock_response = MagicMock()
        mock_response.status_code = 200
        # Mock awaitable return
        future = asyncio.Future()
        future.set_result(mock_response)
        mock_post.return_value = future

        result = await client.send_webhook("http://example.com", {"data": 1})
        assert result is True
        mock_post.assert_called_once()
    await client.close()

@pytest.mark.asyncio
async def test_webhook_retry_logic():
    client = WebhookClient()

    # We want to simulate failures then success to test retry
    # However, testing exact retry timing/count with tenacity can be tricky without mocking time or sleep
    # Here we simulate a permanent failure to ensure it retries 3 times then raises

    with patch.object(client.client, 'post', new_callable=MagicMock) as mock_post:
        # Mock raising HTTP error
        mock_post.side_effect = httpx.RequestError("Connection failed")

        with pytest.raises(httpx.RequestError):
            await client.send_webhook("http://example.com", {"data": 1})

        # Should be called 3 times (1 initial + 2 retries? Or 3 attempts total?)
        # stop_after_attempt(3) means 3 total attempts
        assert mock_post.call_count == 3
    await client.close()

import asyncio
