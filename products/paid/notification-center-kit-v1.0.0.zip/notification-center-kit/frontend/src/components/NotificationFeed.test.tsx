import { render, screen, fireEvent } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import { NotificationFeed } from '../components/NotificationFeed';
import { useNotifications } from '../hooks/useNotifications';

// Mock the custom hook
vi.mock('../hooks/useNotifications', () => ({
  useNotifications: vi.fn()
}));

// Mock Push Manager
vi.mock('../utils/push-manager', () => ({
  subscribeUserToPush: vi.fn()
}));

describe('NotificationFeed', () => {
  const mockMarkAsRead = vi.fn();
  const mockMarkAllAsRead = vi.fn();

  it('renders the bell icon', () => {
    (useNotifications as any).mockReturnValue({
      notifications: [],
      unreadCount: 0,
      isConnected: true,
      markAsRead: mockMarkAsRead,
      markAllAsRead: mockMarkAllAsRead
    });

    render(<NotificationFeed userId="user_123" />);
    expect(document.querySelector('button')).toBeInTheDocument();
  });

  it('shows unread count badge', () => {
    (useNotifications as any).mockReturnValue({
      notifications: [],
      unreadCount: 5,
      isConnected: true,
      markAsRead: mockMarkAsRead,
      markAllAsRead: mockMarkAllAsRead
    });

    render(<NotificationFeed userId="user_123" />);
    expect(screen.getByText('5')).toBeInTheDocument();
  });

  it('opens the dropdown when clicked', () => {
    (useNotifications as any).mockReturnValue({
      notifications: [
        { id: 1, title: 'Test Notif', body: 'Body', is_read: false, created_at: new Date().toISOString() }
      ],
      unreadCount: 1,
      isConnected: true,
      markAsRead: mockMarkAsRead,
      markAllAsRead: mockMarkAllAsRead
    });

    render(<NotificationFeed userId="user_123" />);
    const bellButton = document.querySelector('button');
    if (bellButton) {
        fireEvent.click(bellButton);
    }
    expect(screen.getByText('Test Notif')).toBeInTheDocument();
  });
});
