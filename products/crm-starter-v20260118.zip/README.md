# CRM Starter Kit

Lightweight CRM with lead pipeline and outreach automation

## Contents
- backend/api/routers/crm.py
- scripts/outreach_cli.py
- scripts/proposal_generator.py

## Installation
1. Extract this archive
2. Follow the included documentation

---
Built with 🏯 AgencyOS
Version: 20260118
