# Client Report Generator

Automated weekly client reports with health scoring

## Contents
- scripts/weekly_report.py
- scripts/empire_watcher.py

## Installation
1. Extract this archive
2. Follow the included documentation

---
Built with 🏯 AgencyOS
Version: 20260118
