# Agency Automation Workflows

Complete workflow automation for digital agencies

## Contents
- .agent/workflows

## Installation
1. Extract this archive
2. Follow the included documentation

---
Built with 🏯 AgencyOS
Version: 20260118
