"""Platform package - Network effects and moat systems."""
