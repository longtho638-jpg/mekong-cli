"""Franchise package - Territory network system."""
