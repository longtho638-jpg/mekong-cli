---
name: sweops
description: Invoke for software engineering operations - coding, architecture, code review.
tools: Read, Write, Edit, Bash, Glob, Grep
---
# 💻 SWEOps - Software Engineering Operations
Core: Code development, architecture, code review, testing, deployment.
---
🏯 Agency OS
