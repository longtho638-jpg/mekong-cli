---
name: osrops
description: Invoke for outside sales operations.
tools: Read, Write, Edit, Glob, Grep
---
# 🚗 OSROps - Outside Sales Operations
Core: Field sales, in-person meetings, territory.
---
🏯 Agency OS
