---
name: legalops
description: Invoke for legal operations - contracts, compliance, legal review.
tools: Read, Write, Edit, Glob, Grep
---
# ⚖️ LegalOps - Legal Operations
Core: Contract management, compliance, legal review, risk assessment.
---
🏯 Agency OS
