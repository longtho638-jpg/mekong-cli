---
description: Seed database
---

# Command: /seed

> 🏯 **Binh Pháp**: 地形篇 (Địa Hình) - Database seeding

## Agent Tự Động Thực Hiện

Agent `developer` sẽ tự động:

1. Generate data
2. Insert records
3. Verify
4. Report

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
