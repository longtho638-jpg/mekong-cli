---
description: Run unit tests
---

# Command: /test:unit

> 🏯 **Binh Pháp**: 虛實篇 (Hư Thực) - Unit testing

## Agent Tự Động Thực Hiện

Agent `tester` sẽ tự động:

1. Run tests
2. Report coverage
3. Fix failures

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
