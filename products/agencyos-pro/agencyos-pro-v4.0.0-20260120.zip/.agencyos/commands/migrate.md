---
description: Database migration
---

# Command: /migrate

> 🏯 **Binh Pháp**: 行軍篇 (Hành Quân) - Di chuyển data/schema

## Agent Tự Động Thực Hiện

Agent `developer` sẽ tự động:

1. Schema analysis
2. Generate migration
3. Run migration
4. Verify

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
