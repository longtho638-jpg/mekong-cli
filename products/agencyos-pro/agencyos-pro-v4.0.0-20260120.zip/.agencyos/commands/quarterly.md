---
description: QBR
---

# Command: /quarterly

> 🏯 **Binh Pháp**: 勢篇 (Thế) - Quarterly review

## Agent Tự Động Thực Hiện

Agent `planner` sẽ tự động:

1. Results
2. Analysis
3. Next quarter

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
