---
description: Stage all files and create a commit.
---
Use `git-manager` agent to stage all files and create a commit.
**IMPORTANT: DO NOT push the changes to remote repository**