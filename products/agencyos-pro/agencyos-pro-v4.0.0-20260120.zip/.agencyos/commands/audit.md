---
description: Audit dependencies
---

# Command: /audit

> 🏯 **Binh Pháp**: 用間篇 (Dụng Gián) - Dependency audit

## Agent Tự Động Thực Hiện

Agent `tester` sẽ tự động:

1. Run audit
2. Check vulnerabilities
3. Update deps

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
