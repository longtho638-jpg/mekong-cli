---
description: Deploy to staging
---

# Command: /deploy:staging

> 🏯 **Binh Pháp**: 行軍篇 (Hành Quân) - Staging deployment

## Agent Tự Động Thực Hiện

Agent `developer` sẽ tự động:

1. Build
2. Deploy staging
3. Smoke test
4. Notify

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
