---
description: Generate contract
---

# Command: /contract

> 🏯 **Binh Pháp**: 法篇 (Pháp) - Contract generation

## Agent Tự Động Thực Hiện

Agent `project-manager` sẽ tự động:

1. Terms
2. Scope
3. Pricing

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
