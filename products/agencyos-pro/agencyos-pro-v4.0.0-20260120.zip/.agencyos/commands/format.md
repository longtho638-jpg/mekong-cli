---
description: Format codebase
---

# Command: /format

> 🏯 **Binh Pháp**: 法篇 (Pháp) - Code formatting

## Agent Tự Động Thực Hiện

Agent `tester` sẽ tự động:

1. Run formatter
2. Apply changes
3. Commit

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
