---
description: Performance review
---

# Command: /danh-gia

> 🏯 **Binh Pháp**: 虛實篇 (Hư Thực) - Đánh giá hiệu quả

## Agent Tự Động Thực Hiện

Agent `analyst` sẽ tự động:

1. Metrics
2. Analysis
3. Recommendations

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
