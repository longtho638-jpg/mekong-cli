---
description: Security analysis
---

# Command: /security

> 🏯 **Binh Pháp**: 虛實篇 (Hư Thực) - Security audit

## Agent Tự Động Thực Hiện

Agent `developer` sẽ tự động:

1. Scan vulnerabilities
2. Audit code
3. Fix issues
4. Report

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
