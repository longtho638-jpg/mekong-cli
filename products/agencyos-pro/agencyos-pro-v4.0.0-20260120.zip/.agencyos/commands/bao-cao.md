---
description: General report
---

# Command: /bao-cao

> 🏯 **Binh Pháp**: 計篇 (Kế) - Báo cáo tổng hợp

## Agent Tự Động Thực Hiện

Agent `analyst` sẽ tự động:

1. Tổng hợp
2. Phân tích
3. Kết luận

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
