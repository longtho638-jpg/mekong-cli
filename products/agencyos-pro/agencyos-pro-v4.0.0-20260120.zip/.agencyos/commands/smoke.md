---
description: Run smoke tests
---

# Command: /smoke

> 🏯 **Binh Pháp**: 勢篇 (Thế) - Smoke testing

## Agent Tự Động Thực Hiện

Agent `tester` sẽ tự động:

1. Test critical paths
2. Verify basics
3. Report

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
