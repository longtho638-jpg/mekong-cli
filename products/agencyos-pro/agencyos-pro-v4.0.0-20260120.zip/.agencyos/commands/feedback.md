---
description: Feedback collection
---

# Command: /feedback

> 🏯 **Binh Pháp**: 虛實篇 (Hư Thực) - Collect feedback

## Agent Tự Động Thực Hiện

Agent `project-manager` sẽ tự động:

1. Survey
2. Analysis
3. Improvements

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
