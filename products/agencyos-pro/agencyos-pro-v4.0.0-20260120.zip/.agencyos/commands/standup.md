---
description: Standup notes
---

# Command: /standup

> 🏯 **Binh Pháp**: 行軍篇 (Hành Quân) - Daily standup

## Agent Tự Động Thực Hiện

Agent `planner` sẽ tự động:

1. Yesterday
2. Today
3. Blockers

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
