---
description: Code refactoring
---

# Command: /refactor

> 🏯 **Binh Pháp**: 九變篇 (Cửu Biến) - Biến hoá code structure

## Agent Tự Động Thực Hiện

Agent `developer` sẽ tự động:

1. Analyze code smells
2. Plan refactoring
3. Execute changes
4. Run tests

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
