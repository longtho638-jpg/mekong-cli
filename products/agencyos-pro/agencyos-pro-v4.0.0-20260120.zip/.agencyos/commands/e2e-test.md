---
description: Run E2E tests
---

# Command: /test:e2e

> 🏯 **Binh Pháp**: 火攻篇 (Hoả Công) - End-to-end testing

## Agent Tự Động Thực Hiện

Agent `tester` sẽ tự động:

1. Setup browser
2. Run flows
3. Report

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
