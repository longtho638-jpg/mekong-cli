---
description: Cherry pick commits
---

# Command: /git:cherry

> 🏯 **Binh Pháp**: 用間篇 (Dụng Gián) - Cherry pick

## Agent Tự Động Thực Hiện

Agent `git-manager` sẽ tự động:

1. Find commit
2. Cherry pick
3. Resolve

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
