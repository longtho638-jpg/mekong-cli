---
description: Manage client
---

# Command: /client

> 🏯 **Binh Pháp**: 地形篇 (Địa Hình) - Client management

## Agent Tự Động Thực Hiện

Agent `project-manager` sẽ tự động:

1. Profile
2. History
3. Communications

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
