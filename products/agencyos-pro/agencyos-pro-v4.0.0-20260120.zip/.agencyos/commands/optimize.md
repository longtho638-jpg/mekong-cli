---
description: Optimize performance
---

# Command: /optimize

> 🏯 **Binh Pháp**: 軍爭篇 (Quân Tranh) - Performance optimization

## Agent Tự Động Thực Hiện

Agent `developer` sẽ tự động:

1. Profile app
2. Identify bottlenecks
3. Optimize
4. Benchmark

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
