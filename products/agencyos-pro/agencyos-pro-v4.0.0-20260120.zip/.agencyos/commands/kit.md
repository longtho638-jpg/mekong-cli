---
description: Manage Antigravity Kit modules
---

# 🌌 Kit Command Center

Manage your installed Antigravity modules.

## Usage

```bash
/kit <subcommand>
```

## Subcommands

- `status`: Check system status.
- `sync`: Synchronize all modules.
