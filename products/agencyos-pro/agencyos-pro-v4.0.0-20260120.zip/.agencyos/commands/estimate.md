---
description: Estimate work
---

# Command: /estimate

> 🏯 **Binh Pháp**: 計篇 (Kế) - Time estimation

## Agent Tự Động Thực Hiện

Agent `project-manager` sẽ tự động:

1. Break down tasks
2. Estimate hours
3. Buffer

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
