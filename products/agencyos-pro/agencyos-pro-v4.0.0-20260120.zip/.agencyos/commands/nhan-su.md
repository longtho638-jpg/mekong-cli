---
description: HR management
---

# Command: /nhan-su

> 🏯 **Binh Pháp**: 法篇 (Pháp) - Quản lý nhân sự

## Agent Tự Động Thực Hiện

Agent `project-manager` sẽ tự động:

1. Profiles
2. Roles
3. Performance

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
