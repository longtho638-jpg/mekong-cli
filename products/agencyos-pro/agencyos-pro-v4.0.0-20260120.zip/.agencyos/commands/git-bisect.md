---
description: Find bug commit
---

# Command: /git:bisect

> 🏯 **Binh Pháp**: 火攻篇 (Hoả Công) - Git bisect

## Agent Tự Động Thực Hiện

Agent `git-manager` sẽ tự động:

1. Start bisect
2. Test
3. Find culprit

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
