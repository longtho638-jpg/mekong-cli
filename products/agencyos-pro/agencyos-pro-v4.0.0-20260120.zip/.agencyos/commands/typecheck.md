---
description: Type check codebase
---

# Command: /typecheck

> 🏯 **Binh Pháp**: 軍形篇 (Quân Hình) - Type checking

## Agent Tự Động Thực Hiện

Agent `tester` sẽ tự động:

1. Run tsc
2. Report errors
3. Fix issues

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
