# AgencyOS Core License

Complete Venture Operating System source code

## Contents
- packages/antigravity
- scripts
- .agent

## Installation
1. Extract this archive
2. Follow the included documentation

---
Built with 🏯 AgencyOS
Version: 20260118
