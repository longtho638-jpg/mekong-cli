#!/usr/bin/env python3
"""
🏯 Viettel Bypass Multi-Solution Toolkit
Binh Pháp: Khi một đường không thông, mở nhiều đường khác

Solutions:
1. Google One VPN (nếu có subscription)
2. WARP + DoH combo
3. Tailscale + Exit Node
4. SSH Tunnel (nếu có VPS)
5. Outline VPN (self-hosted)
"""

import subprocess
import sys
import time


def run_cmd(cmd: str, timeout: int = 10) -> tuple:
    """Run command and return (success, output)"""
    try:
        result = subprocess.run(
            cmd, shell=True, capture_output=True, text=True, timeout=timeout
        )
        return result.returncode == 0, result.stdout + result.stderr
    except Exception as e:
        return False, str(e)


def test_google():
    """Test Google latency"""
    success, output = run_cmd(
        "curl -s -o /dev/null -w '%{time_total}' https://www.google.com", timeout=15
    )
    if success:
        try:
            return float(output) * 1000
        except:
            pass
    return 9999


def get_current_ip():
    """Get current public IP and location"""
    success, output = run_cmd("curl -s https://ipinfo.io/json", timeout=10)
    if success:
        import json

        try:
            data = json.loads(output)
            return f"{data.get('ip')} ({data.get('city')}, {data.get('country')})"
        except:
            pass
    return "Unknown"


# ============================================
# SOLUTION 1: WARP + DNS over HTTPS
# ============================================
def solution_warp_doh():
    """WARP with 1.1.1.1 DoH for extra bypass"""
    print("\n🔷 SOLUTION 1: WARP + DoH Combo")
    print("=" * 50)

    # Check WARP status
    success, output = run_cmd("warp-cli status")
    if "Connected" not in output:
        print("  ⚠️  WARP not connected. Connecting...")
        run_cmd("warp-cli connect")
        time.sleep(5)

    # Set DNS to 1.1.1.1 DoH
    print("  📡 Setting DNS to Cloudflare DoH...")
    run_cmd("networksetup -setdnsservers Wi-Fi 1.1.1.1 1.0.0.1")

    latency = test_google()
    print(f"  📊 Google latency: {latency:.0f}ms")

    return latency < 500


# ============================================
# SOLUTION 2: Tailscale Exit Node
# ============================================
def solution_tailscale():
    """Use Tailscale with Mullvad exit nodes"""
    print("\n🔷 SOLUTION 2: Tailscale Exit Nodes")
    print("=" * 50)

    # Check Tailscale
    success, output = run_cmd("tailscale status")
    if not success:
        print("  ❌ Tailscale not running")
        return False

    # List exit nodes
    success, nodes = run_cmd("tailscale exit-node list")
    if "mullvad" in nodes.lower() or len(nodes.strip()) > 0:
        print("  ✅ Exit nodes available")
        print("  💡 Command to use Singapore exit node:")
        print("     tailscale set --exit-node=<sg-node>")
    else:
        print("  ⚠️  No Mullvad exit nodes. To enable:")
        print("     1. Go to Tailscale Admin Console")
        print("     2. Enable Mullvad VPN integration")
        print("     3. Choose Singapore/Tokyo server")

    return True


# ============================================
# SOLUTION 3: SSH SOCKS Proxy (nếu có VPS)
# ============================================
def solution_ssh_proxy():
    """SSH Dynamic Port Forwarding"""
    print("\n🔷 SOLUTION 3: SSH SOCKS Proxy")
    print("=" * 50)
    print("  Nếu anh có VPS ở Singapore/Japan:")
    print("")
    print("  # Tạo SOCKS5 proxy trên port 1080")
    print("  ssh -D 1080 -N -f user@vps-ip")
    print("")
    print("  # Set proxy trong System Preferences")
    print("  # hoặc dùng trong browser")
    print("")
    print("  # Test với curl:")
    print("  curl --socks5 127.0.0.1:1080 https://google.com")
    return True


# ============================================
# SOLUTION 4: Outline VPN (By Google Jigsaw)
# ============================================
def solution_outline():
    """Outline VPN - Self-hosted Shadowsocks"""
    print("\n🔷 SOLUTION 4: Outline VPN")
    print("=" * 50)
    print("  Outline = Shadowsocks by Google Jigsaw")
    print("")
    print("  📥 Install:")
    print("     brew install --cask outline-client")
    print("")
    print("  🖥️  Host your own server (1-click deploy):")
    print("     https://getoutline.org/get-started/")
    print("")
    print("  Supports: DigitalOcean, Vultr, AWS, GCP")
    print("  → Chọn server Singapore/Tokyo")
    return True


# ============================================
# SOLUTION 5: Direct WireGuard to VPS
# ============================================
def solution_wireguard():
    """WireGuard VPN to self-hosted VPS"""
    print("\n🔷 SOLUTION 5: WireGuard VPN")
    print("=" * 50)
    print("  Nếu anh có VPS:")
    print("")
    print("  # On VPS (Ubuntu):")
    print(
        "  curl -O https://raw.githubusercontent.com/angristan/wireguard-install/master/wireguard-install.sh"
    )
    print("  chmod +x wireguard-install.sh")
    print("  ./wireguard-install.sh")
    print("")
    print("  # On Mac:")
    print("  brew install wireguard-tools")
    print("  # Import config vào WireGuard GUI")
    return True


# ============================================
# SOLUTION 6: V2Ray/Xray (Advanced)
# ============================================
def solution_v2ray():
    """V2Ray/Xray - Advanced proxy"""
    print("\n🔷 SOLUTION 6: V2Ray/Xray (Advanced)")
    print("=" * 50)
    print("  Protocol thường dùng để bypass GFW")
    print("  Có thể dùng với: VMESS, VLESS, Trojan")
    print("")
    print("  📥 Client cho Mac:")
    print("     brew install --cask v2rayu")
    print("     # hoặc")
    print("     brew install --cask clashx")
    print("")
    print("  🖥️  Server setup:")
    print(
        "     bash <(curl -L https://raw.githubusercontent.com/v2fly/fhs-install-v2ray/master/install-release.sh)"
    )
    return True


# ============================================
# QUICK FIX: Google DNS
# ============================================
def quick_fix_dns():
    """Quick fix: Change DNS"""
    print("\n⚡ QUICK FIX: DNS Settings")
    print("=" * 50)

    print("  Setting DNS to Google + Cloudflare...")
    run_cmd("networksetup -setdnsservers Wi-Fi 8.8.8.8 8.8.4.4 1.1.1.1")

    # Flush DNS
    run_cmd("sudo dscacheutil -flushcache 2>/dev/null")
    run_cmd("sudo killall -HUP mDNSResponder 2>/dev/null")

    time.sleep(2)
    latency = test_google()
    print(f"  📊 Google latency after DNS change: {latency:.0f}ms")

    return latency < 500


def main():
    print("🏯 VIETTEL BYPASS TOOLKIT")
    print("=" * 60)

    # Current status
    ip = get_current_ip()
    latency = test_google()
    print(f"📍 Current IP: {ip}")
    print(f"⏱️  Google latency: {latency:.0f}ms")

    if len(sys.argv) > 1:
        cmd = sys.argv[1]
        if cmd == "warp":
            solution_warp_doh()
        elif cmd == "tailscale":
            solution_tailscale()
        elif cmd == "dns":
            quick_fix_dns()
        elif cmd == "all":
            solution_warp_doh()
            solution_tailscale()
            solution_ssh_proxy()
            solution_outline()
            solution_wireguard()
            solution_v2ray()
    else:
        print("\nUsage:")
        print("  python viettel_bypass.py warp      # WARP + DoH")
        print("  python viettel_bypass.py tailscale # Tailscale info")
        print("  python viettel_bypass.py dns       # Quick DNS fix")
        print("  python viettel_bypass.py all       # Show all solutions")
        print()

        # Quick DNS fix first
        quick_fix_dns()

        print("\n" + "=" * 60)
        print("📌 RECOMMENDED SOLUTIONS:")
        print("=" * 60)
        print("""
1. 🥇 OUTLINE VPN (Best for Viettel)
   → Self-host trên DigitalOcean Singapore ($5/mo)
   → Protocol: Shadowsocks (hard to detect/block)
   → Install: brew install --cask outline-client

2. 🥈 TAILSCALE + MULLVAD
   → Bật Mullvad integration trong Tailscale Admin
   → Chọn exit node: Singapore hoặc Tokyo
   → Không cần self-host

3. 🥉 VPS + WIREGUARD  
   → Mua VPS Singapore (Vultr/DO/Linode ~$5/mo)
   → Cài WireGuard 1-click script
   → Direct tunnel, fast

4. 💡 QUICK FIXES (no VPS needed):
   → WARP + DoH (current)
   → Google DNS: 8.8.8.8, 8.8.4.4
   → Cloudflare DNS: 1.1.1.1, 1.0.0.1
""")


if __name__ == "__main__":
    main()
