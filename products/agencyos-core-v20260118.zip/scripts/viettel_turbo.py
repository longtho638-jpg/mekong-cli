#!/usr/bin/env python3
"""
🚀 VIETTEL TURBO - Ultimate Network Optimizer
Auto-finds best endpoint and keeps connection optimal

WIN-WIN-WIN:
- Anh WIN: Fastest possible connection to Google
- Agency WIN: Reusable automation
- Network WIN: Optimal routing
"""

import json
import subprocess
import sys
import time

# Best endpoints from testing
OPTIMAL_ENDPOINTS = [
    ("162.159.193.1", 2408),  # Often routes to SIN
    ("162.159.192.1", 2408),
    ("162.159.195.1", 2408),
    ("162.159.193.1", 500),
    ("162.159.192.1", 500),
    ("162.159.193.1", 4500),
    ("162.159.192.1", 4500),
]


def run(cmd: str, timeout: int = 10) -> str:
    """Run command"""
    try:
        r = subprocess.run(
            cmd, shell=True, capture_output=True, text=True, timeout=timeout
        )
        return r.stdout + r.stderr
    except:
        return ""


def get_colo() -> str:
    """Get current Cloudflare colo"""
    out = run("curl -s https://cloudflare.com/cdn-cgi/trace 2>/dev/null | grep colo")
    if "colo=" in out:
        return out.split("=")[1].strip()
    return "UNKNOWN"


def get_google_latency() -> float:
    """Test Google latency in ms"""
    out = run(
        "curl -s -o /dev/null -w '%{time_total}' https://www.google.com 2>/dev/null", 15
    )
    try:
        return float(out) * 1000
    except:
        return 9999


def set_endpoint(ip: str, port: int) -> bool:
    """Set WARP endpoint"""
    run("warp-cli disconnect 2>/dev/null")
    time.sleep(1)
    run(f"warp-cli tunnel endpoint set {ip}:{port} 2>/dev/null")
    time.sleep(1)
    run("warp-cli connect 2>/dev/null")
    time.sleep(4)

    # Verify connected
    status = run("warp-cli status")
    return "Connected" in status


def set_optimal_dns():
    """Set Google + Cloudflare DNS"""
    run("networksetup -setdnsservers Wi-Fi 8.8.8.8 8.8.4.4 1.1.1.1 1.0.0.1")
    run("sudo dscacheutil -flushcache 2>/dev/null")
    run("sudo killall -HUP mDNSResponder 2>/dev/null")


def find_best_endpoint():
    """Find the endpoint with lowest Google latency"""
    print("🔍 Finding optimal endpoint...")
    print("=" * 50)

    results = []

    for ip, port in OPTIMAL_ENDPOINTS:
        print(f"  Testing {ip}:{port}...", end=" ", flush=True)

        if set_endpoint(ip, port):
            colo = get_colo()
            latency = get_google_latency()

            results.append({"ip": ip, "port": port, "colo": colo, "latency": latency})

            print(f"{colo} → {latency:.0f}ms")

            # Early exit if we find SGN or very low latency
            if colo == "SGN" or latency < 100:
                print(f"  ✅ Found optimal: {colo} at {latency:.0f}ms!")
                return results[-1]
        else:
            print("❌ Failed to connect")

    # Return best result
    if results:
        best = min(results, key=lambda x: x["latency"])
        return best

    return None


def turbo_mode():
    """Full optimization"""
    print("\n🚀 VIETTEL TURBO MODE")
    print("=" * 60)

    # Step 1: Optimal DNS
    print("\n📡 Step 1: Setting optimal DNS...")
    set_optimal_dns()
    print("  ✅ DNS: 8.8.8.8, 1.1.1.1")

    # Step 2: Find best WARP endpoint
    print("\n🔄 Step 2: Finding best WARP endpoint...")
    best = find_best_endpoint()

    if best:
        print(f"\n✅ OPTIMAL ENDPOINT: {best['ip']}:{best['port']}")
        print(f"   Colo: {best['colo']}")
        print(f"   Google: {best['latency']:.0f}ms")

        # Final speed test
        print("\n📊 Step 3: Final speed test...")
        speed = run(
            "curl -s -o /dev/null -w '%{speed_download}' 'https://speed.cloudflare.com/__down?bytes=10000000' 2>/dev/null",
            30,
        )
        try:
            speed_mbps = float(speed) / 1024 / 1024 * 8
            print(f"   Download: {speed_mbps:.1f} Mbps")
        except:
            print("   Download: N/A")

        # Save config
        config = {
            "optimal_endpoint": f"{best['ip']}:{best['port']}",
            "colo": best["colo"],
            "last_optimized": time.strftime("%Y-%m-%d %H:%M:%S"),
            "google_latency_ms": best["latency"],
        }

        config_path = "/Users/macbookprom1/mekong-cli/.warp_config.json"
        with open(config_path, "w") as f:
            json.dump(config, f, indent=2)
        print(f"\n💾 Config saved: {config_path}")

        return True

    print("❌ No working endpoint found")
    return False


def quick_connect():
    """Quick connect using saved config"""
    config_path = "/Users/macbookprom1/mekong-cli/.warp_config.json"
    try:
        with open(config_path) as f:
            config = json.load(f)

        endpoint = config["optimal_endpoint"]
        ip, port = endpoint.split(":")

        print(f"⚡ Quick connecting to {endpoint} ({config['colo']})...")
        set_optimal_dns()

        if set_endpoint(ip, int(port)):
            latency = get_google_latency()
            print(f"✅ Connected! Google: {latency:.0f}ms")
            return True
    except:
        print("❌ No saved config. Run 'turbo' first.")

    return False


def status():
    """Show current status"""
    print("\n📊 CURRENT STATUS")
    print("=" * 50)

    warp = run("warp-cli status 2>/dev/null")
    connected = "Connected" in warp

    print(f"WARP: {'✅ Connected' if connected else '❌ Disconnected'}")

    if connected:
        colo = get_colo()
        latency = get_google_latency()
        print(f"Colo: {colo}")
        print(f"Google: {latency:.0f}ms")

        # Speed test
        speed = run(
            "curl -s -o /dev/null -w '%{speed_download}' 'https://speed.cloudflare.com/__down?bytes=5000000' 2>/dev/null",
            20,
        )
        try:
            speed_mbps = float(speed) / 1024 / 1024 * 8
            print(f"Speed: {speed_mbps:.1f} Mbps")
        except:
            pass


def main():
    if len(sys.argv) < 2:
        print("🚀 VIETTEL TURBO - Network Optimizer")
        print()
        print("Usage:")
        print(
            "  python viettel_turbo.py turbo   # Full optimization (find best endpoint)"
        )
        print("  python viettel_turbo.py quick   # Quick connect using saved config")
        print("  python viettel_turbo.py status  # Show current status")
        print()
        status()
        return

    cmd = sys.argv[1].lower()

    if cmd == "turbo":
        turbo_mode()
    elif cmd == "quick":
        quick_connect()
    elif cmd == "status":
        status()
    else:
        print(f"Unknown command: {cmd}")


if __name__ == "__main__":
    main()
