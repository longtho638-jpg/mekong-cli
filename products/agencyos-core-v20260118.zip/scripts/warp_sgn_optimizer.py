#!/usr/bin/env python3
"""
🏯 WARP SGN Optimizer - Force Viettel to SGN Node
Binh Pháp Strategy: Bypass ISP throttling by finding optimal Cloudflare endpoints

Win-Win-Win:
- Anh WIN: Fast Google access, no throttling
- Agency WIN: Reusable automation script
- Network WIN: Optimal routing path
"""

import concurrent.futures
import socket
import subprocess
import sys
import time

# Known Cloudflare WARP endpoints with different ports
WARP_ENDPOINTS = [
    # Primary endpoints
    ("162.159.192.1", 2408),
    ("162.159.193.1", 2408),
    ("162.159.195.1", 2408),
    ("162.159.192.1", 500),
    ("162.159.193.1", 500),
    ("162.159.195.1", 500),
    ("162.159.192.1", 1701),
    ("162.159.193.1", 1701),
    ("162.159.192.1", 4500),
    ("162.159.193.1", 4500),
    # IPv6 endpoints (if supported)
    ("2606:4700:d0::a29f:c001", 2408),
    ("2606:4700:d1::a29f:c101", 2408),
]

# Additional anycast IPs that may route to different PoPs
ANYCAST_IPS = [
    "162.159.192.1",
    "162.159.193.1",
    "162.159.195.1",
    "162.159.192.2",
    "162.159.193.2",
    "162.159.195.2",
    "162.159.192.5",
    "162.159.193.5",
    "162.159.195.5",
    "162.159.192.10",
    "162.159.193.10",
]

PORTS = [
    500,
    854,
    859,
    864,
    878,
    880,
    890,
    891,
    894,
    903,
    908,
    928,
    934,
    939,
    942,
    943,
    945,
    946,
    955,
    968,
    987,
    988,
    1002,
    1010,
    1014,
    1018,
    1070,
    1074,
    1180,
    1387,
    1701,
    1843,
    2371,
    2408,
    2506,
    3138,
    3476,
    3581,
    3854,
    4177,
    4198,
    4233,
    4500,
    5279,
    5956,
    7103,
    7152,
    7156,
    7281,
    7559,
    8319,
    8742,
    8854,
    8886,
]


def test_endpoint_latency(ip: str, port: int, timeout: float = 2.0) -> tuple:
    """Test UDP latency to endpoint"""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(timeout)
        start = time.time()
        sock.sendto(b"\x00" * 32, (ip, port))
        # Just measure send time since UDP is connectionless
        latency = (time.time() - start) * 1000
        sock.close()
        return (ip, port, latency, True)
    except Exception:
        return (ip, port, 9999, False)


def get_current_colo():
    """Get current Cloudflare colo"""
    try:
        result = subprocess.run(
            ["curl", "-s", "https://cloudflare.com/cdn-cgi/trace"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        for line in result.stdout.split("\n"):
            if line.startswith("colo="):
                return line.split("=")[1]
    except:
        pass
    return "UNKNOWN"


def set_warp_endpoint(ip: str, port: int):
    """Set WARP endpoint via CLI"""
    try:
        subprocess.run(["warp-cli", "disconnect"], capture_output=True, timeout=5)
        time.sleep(1)
        subprocess.run(
            ["warp-cli", "tunnel", "endpoint", "set", f"{ip}:{port}"],
            capture_output=True,
            timeout=5,
        )
        time.sleep(1)
        subprocess.run(["warp-cli", "connect"], capture_output=True, timeout=5)
        time.sleep(3)
        return True
    except:
        return False


def find_sgn_endpoint():
    """Scan all endpoints to find one that routes to SGN"""
    print("🔍 Scanning for SGN (Saigon) endpoint...")
    print("=" * 60)

    tested = []

    # Test all combinations
    for ip in ANYCAST_IPS[:5]:  # Limit for speed
        for port in [2408, 500, 4500, 1701, 854]:  # Most common ports
            print(f"  Testing {ip}:{port}...", end=" ", flush=True)

            if set_warp_endpoint(ip, port):
                colo = get_current_colo()

                # Check latency to Google
                google_latency = test_google_latency()

                result = {
                    "ip": ip,
                    "port": port,
                    "colo": colo,
                    "google_ms": google_latency,
                }
                tested.append(result)

                status = "✅ SGN!" if colo == "SGN" else f"→ {colo}"
                print(f"{status} (Google: {google_latency:.0f}ms)")

                if colo == "SGN":
                    return result
            else:
                print("❌ Failed")

    # If no SGN found, return best option
    if tested:
        # Sort by Google latency
        tested.sort(key=lambda x: x["google_ms"])
        return tested[0]

    return None


def test_google_latency() -> float:
    """Test latency to Google"""
    try:
        start = time.time()
        result = subprocess.run(
            [
                "curl",
                "-s",
                "-o",
                "/dev/null",
                "-w",
                "%{time_total}",
                "https://www.google.com/generate_204",
            ],
            capture_output=True,
            text=True,
            timeout=10,
        )
        return float(result.stdout) * 1000
    except:
        return 9999


def optimize_for_google():
    """Find the best endpoint for Google access"""
    print("\n🚀 WARP SGN Optimizer for Viettel → Google")
    print("=" * 60)

    # Get current status
    current_colo = get_current_colo()
    google_before = test_google_latency()

    print(f"📍 Current: {current_colo}")
    print(f"⏱️  Google latency: {google_before:.0f}ms")
    print()

    # Find best endpoint
    best = find_sgn_endpoint()

    if best:
        print()
        print("=" * 60)
        print("✅ BEST ENDPOINT FOUND:")
        print(f"   IP: {best['ip']}:{best['port']}")
        print(f"   Colo: {best['colo']}")
        print(f"   Google: {best['google_ms']:.0f}ms")

        if best["colo"] != "SGN":
            print()
            print("⚠️  SGN not available from Viettel routing")
            print(f"   Using {best['colo']} (best available)")

        return best
    else:
        print("❌ No working endpoint found")
        return None


def main():
    if len(sys.argv) > 1 and sys.argv[1] == "--scan":
        # Quick latency scan only
        print("🔍 Scanning endpoint latencies...")
        results = []

        with concurrent.futures.ThreadPoolExecutor(max_workers=20) as executor:
            futures = []
            for ip in ANYCAST_IPS:
                for port in [2408, 500, 4500]:
                    futures.append(executor.submit(test_endpoint_latency, ip, port))

            for future in concurrent.futures.as_completed(futures):
                result = future.result()
                if result[3]:  # success
                    results.append(result)

        results.sort(key=lambda x: x[2])

        print("\n📊 Top 10 Lowest Latency Endpoints:")
        for ip, port, latency, _ in results[:10]:
            print(f"   {ip}:{port} → {latency:.1f}ms")
    else:
        optimize_for_google()


if __name__ == "__main__":
    main()
