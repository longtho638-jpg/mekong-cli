#!/usr/bin/env python3
"""
🌐 Network Optimizer - AgencyOS
Auto-maintains optimal network connectivity for Vietnam ISP bypass.

Strategy: WARP-first (FREE, stable, HKG/SIN routing)
Fallback: Mullvad via Tailscale (when WARP fails)

Usage:
    python3 network_optimizer.py          # Run once
    python3 network_optimizer.py --daemon # Run continuously
    python3 network_optimizer.py --status # Check status only
"""

import json
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

# Configuration
PING_TARGET = "1.1.1.1"
PING_THRESHOLD_MS = 100
CHECK_INTERVAL = 60  # seconds
LOG_FILE = Path.home() / ".network_optimizer.log"

# Preferred exit nodes (ordered by priority)
MULLVAD_NODES = [
    "sg-sin-wg-001.mullvad.ts.net",  # Singapore
    "hk-hkg-wg-201.mullvad.ts.net",  # Hong Kong
    "jp-tyo-wg-001.mullvad.ts.net",  # Tokyo
]


def log(msg: str):
    """Log with timestamp"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def run_cmd(cmd: str, timeout: int = 30) -> tuple[int, str]:
    """Run command and return (exit_code, output)"""
    try:
        result = subprocess.run(
            cmd, shell=True, capture_output=True, text=True, timeout=timeout
        )
        return result.returncode, result.stdout + result.stderr
    except subprocess.TimeoutExpired:
        return -1, "Command timed out"
    except Exception as e:
        return -1, str(e)


def get_warp_status() -> dict:
    """Get WARP connection status"""
    code, output = run_cmd("warp-cli status")
    connected = "Connected" in output
    healthy = "healthy" in output.lower()
    return {"connected": connected, "healthy": healthy, "output": output}


def get_tailscale_status() -> dict:
    """Get Tailscale status"""
    code, output = run_cmd("tailscale status --json")
    if code != 0:
        return {"online": False, "exit_node": None, "error": output}

    try:
        data = json.loads(output)
        exit_node = data.get("ExitNodeStatus", {})
        return {
            "online": data.get("Self", {}).get("Online", False),
            "exit_node_active": exit_node.get("Online", False),
            "exit_node_id": exit_node.get("ID"),
        }
    except:
        return {"online": False, "exit_node": None}


def get_ping_latency() -> float:
    """Get ping latency to Cloudflare"""
    code, output = run_cmd(f"ping -c 3 {PING_TARGET}")
    if code != 0:
        return 999.0

    # Parse avg from: min/avg/max/stddev = x/y/z/w ms
    try:
        for line in output.split("\n"):
            if "avg" in line:
                parts = line.split("=")[1].strip().split("/")
                return float(parts[1])
    except:
        pass
    return 999.0


def get_cloudflare_colo() -> str:
    """Get Cloudflare datacenter colo"""
    code, output = run_cmd("curl -s https://cloudflare.com/cdn-cgi/trace", timeout=10)
    if code != 0:
        return "UNKNOWN"

    for line in output.split("\n"):
        if line.startswith("colo="):
            return line.split("=")[1]
    return "UNKNOWN"


def connect_warp() -> bool:
    """Connect to WARP"""
    log("🔄 Connecting WARP...")
    code, _ = run_cmd("warp-cli connect")
    time.sleep(3)
    status = get_warp_status()
    if status["connected"]:
        log("✅ WARP connected successfully")
        return True
    log("❌ WARP connection failed")
    return False


def disconnect_warp() -> bool:
    """Disconnect WARP"""
    log("🔄 Disconnecting WARP...")
    code, _ = run_cmd("warp-cli disconnect")
    return code == 0


def disable_tailscale_exit() -> bool:
    """Disable Tailscale exit node to avoid conflicts"""
    log("🔄 Disabling Tailscale exit node...")
    code, _ = run_cmd("tailscale set --exit-node=")
    return code == 0


def enable_tailscale_exit(node: str) -> bool:
    """Enable specific Tailscale exit node"""
    log(f"🔄 Enabling Tailscale exit node: {node}")
    code, _ = run_cmd(
        f"tailscale up --accept-routes --exit-node={node} --exit-node-allow-lan-access"
    )
    time.sleep(5)
    return code == 0


def optimize_network():
    """Main optimization logic"""
    log("=" * 50)
    log("🌐 Network Optimizer Starting...")

    # Step 1: Check WARP status
    warp = get_warp_status()
    log(f"WARP: {'✅ Connected' if warp['connected'] else '❌ Disconnected'}")

    # Step 2: Disable Tailscale exit node if active (prevent conflicts)
    ts = get_tailscale_status()
    if ts.get("exit_node_active"):
        log("⚠️ Tailscale exit node active - disabling to avoid conflict")
        disable_tailscale_exit()

    # Step 3: Ensure WARP is connected
    if not warp["connected"]:
        if not connect_warp():
            log("⚠️ WARP failed, trying Mullvad fallback...")
            # Fallback to Mullvad
            for node in MULLVAD_NODES:
                if enable_tailscale_exit(node):
                    latency = get_ping_latency()
                    if latency < PING_THRESHOLD_MS:
                        log(f"✅ Mullvad {node} active - {latency}ms")
                        return True
            log("❌ All network options failed!")
            return False

    # Step 4: Verify connection quality
    latency = get_ping_latency()
    colo = get_cloudflare_colo()

    log(f"📍 Cloudflare Colo: {colo}")
    log(f"⏱️ Ping Latency: {latency}ms")

    if latency > PING_THRESHOLD_MS:
        log(f"⚠️ High latency ({latency}ms), consider switching nodes")
    else:
        log(f"✅ Network optimal! ({latency}ms via {colo})")

    return True


def print_status():
    """Print current network status"""
    print("\n🌐 Network Status")
    print("=" * 40)

    warp = get_warp_status()
    print(f"WARP: {'✅ Connected' if warp['connected'] else '❌ Disconnected'}")

    ts = get_tailscale_status()
    print(f"Tailscale: {'✅ Online' if ts.get('online') else '❌ Offline'}")
    print(f"Exit Node: {'✅ Active' if ts.get('exit_node_active') else '❌ Disabled'}")

    colo = get_cloudflare_colo()
    latency = get_ping_latency()
    print(f"\n📍 Cloudflare Colo: {colo}")
    print(f"⏱️ Ping (1.1.1.1): {latency}ms")

    if latency < 50:
        print("✅ Network: EXCELLENT")
    elif latency < 100:
        print("✅ Network: GOOD")
    else:
        print("⚠️ Network: POOR - consider reconnecting")
    print()


def daemon_mode():
    """Run continuously"""
    log("🚀 Starting daemon mode...")
    while True:
        try:
            optimize_network()
            time.sleep(CHECK_INTERVAL)
        except KeyboardInterrupt:
            log("👋 Daemon stopped by user")
            break
        except Exception as e:
            log(f"❌ Error: {e}")
            time.sleep(CHECK_INTERVAL)


if __name__ == "__main__":
    if len(sys.argv) > 1:
        if sys.argv[1] == "--daemon":
            daemon_mode()
        elif sys.argv[1] == "--status":
            print_status()
        else:
            print(__doc__)
    else:
        optimize_network()
        print_status()
