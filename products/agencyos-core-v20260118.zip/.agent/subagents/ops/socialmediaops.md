---
name: socialmediaops
description: Invoke for social media operations - posting, engagement, community management.
tools: Read, Write, Edit, Glob, Grep
---
# 📱 SocialMediaOps - Social Media Operations
Core: Content scheduling, engagement, community management, analytics.
---
🏯 Agency OS
