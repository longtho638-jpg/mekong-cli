# Copy Brief Template

## Project Info

| Field | Value |
|-------|-------|
| Project | |
| Deliverable | |
| Due Date | |
| Writer | |

## Audience

**Who:**
**Pain points:**
**Goals:**
**Awareness level:** (Unaware / Problem-aware / Solution-aware / Product-aware)

## Copy Details

**Type:** (headline / email / landing page / ad / social)
**Tone:** (professional / casual / urgent / playful)
**Length:**
**Primary CTA:**

## Key Messages

1.
2.
3.

## Proof Points

-
-

## Constraints

- Must include:
- Must avoid:
- Brand voice notes:

## Formula to Use

[ ] AIDA  [ ] PAS  [ ] BAB  [ ] 4Ps  [ ] FAB

## Success Metrics

-
