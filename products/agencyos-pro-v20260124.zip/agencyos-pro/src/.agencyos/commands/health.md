---
description: System health
---

# Command: /health

> 🏯 **Binh Pháp**: 虛實篇 (Hư Thực) - Health check

## Agent Tự Động Thực Hiện

Agent `developer` sẽ tự động:

1. Dependencies
2. Services
3. Report

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
