---
description: Create release tag
---

# Command: /git:tag

> 🏯 **Binh Pháp**: 計篇 (Kế) - Tag release

## Agent Tự Động Thực Hiện

Agent `git-manager` sẽ tự động:

1. Version bump
2. Create tag
3. Push

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
