---
description: Build API endpoints
---

# Command: /api

> 🏯 **Binh Pháp**: 法篇 (Pháp) - API development

## Agent Tự Động Thực Hiện

Agent `developer` sẽ tự động:

1. Design spec
2. Generate endpoints
3. Add validation
4. Document

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
