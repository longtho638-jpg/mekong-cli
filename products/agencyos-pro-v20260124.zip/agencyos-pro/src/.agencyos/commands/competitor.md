---
description: Analyze competitors
---

# Command: /competitor

> 🏯 **Binh Pháp**: 用間篇 (Dụng Gián) - Competitor analysis

## Agent Tự Động Thực Hiện

Agent `researcher` sẽ tự động:

1. Identify competitors
2. Analyze features
3. Compare pricing
4. Report

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
