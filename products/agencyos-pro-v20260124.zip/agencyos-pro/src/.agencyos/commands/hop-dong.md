---
description: Contract VN
---

# Command: /hop-dong

> 🏯 **Binh Pháp**: 法篇 (Pháp) - Hợp đồng

## Agent Tự Động Thực Hiện

Agent `project-manager` sẽ tự động:

1. Terms
2. Legal
3. Generate

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
