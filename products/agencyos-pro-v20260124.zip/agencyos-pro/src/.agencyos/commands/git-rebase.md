---
description: Rebase branch
---

# Command: /git:rebase

> 🏯 **Binh Pháp**: 行軍篇 (Hành Quân) - Rebase branch

## Agent Tự Động Thực Hiện

Agent `git-manager` sẽ tự động:

1. Fetch upstream
2. Rebase
3. Push

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
