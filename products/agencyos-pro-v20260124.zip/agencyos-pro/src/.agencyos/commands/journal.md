---
description: ⚡ Write some journal entries.
---

Use the `journal-writer` subagent to explore the memories and recent code changes, and write some journal entries.
