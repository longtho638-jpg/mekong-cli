---
description: Deploy to production
---

# Command: /deploy:prod

> 🏯 **Binh Pháp**: 火攻篇 (Hoả Công) - Production deployment

## Agent Tự Động Thực Hiện

Agent `developer` sẽ tự động:

1. Build check
2. Run tests
3. Deploy
4. Monitor

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
