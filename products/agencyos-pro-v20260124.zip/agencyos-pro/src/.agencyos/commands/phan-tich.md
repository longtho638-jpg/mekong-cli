---
description: Market analysis VN
---

# Command: /phan-tich

> 🏯 **Binh Pháp**: 用間篇 (Dụng Gián) - Phân tích thị trường

## Agent Tự Động Thực Hiện

Agent `researcher` sẽ tự động:

1. Thu thập data
2. Phân tích
3. Báo cáo

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
