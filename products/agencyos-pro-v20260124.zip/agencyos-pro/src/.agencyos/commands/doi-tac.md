---
description: Partner relations
---

# Command: /doi-tac

> 🏯 **Binh Pháp**: 用間篇 (Dụng Gián) - Quan hệ đối tác

## Agent Tự Động Thực Hiện

Agent `researcher` sẽ tự động:

1. Research
2. Outreach
3. Management

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
