---
description: Generate report
---

# Command: /report

> 🏯 **Binh Pháp**: 計篇 (Kế) - Status report

## Agent Tự Động Thực Hiện

Agent `project-manager` sẽ tự động:

1. Progress
2. Issues
3. Next steps

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
