---
description: Create invoice
---

# Command: /invoice:gen

> 🏯 **Binh Pháp**: 法篇 (Pháp) - Invoice creation

## Agent Tự Động Thực Hiện

Agent `project-manager` sẽ tự động:

1. Line items
2. Calculate
3. Generate

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
