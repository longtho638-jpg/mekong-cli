---
description: Handoff deliverables
---

# Command: /handoff

> 🏯 **Binh Pháp**: 火攻篇 (Hoả Công) - Client handoff

## Agent Tự Động Thực Hiện

Agent `project-manager` sẽ tự động:

1. Package
2. Docs
3. Training

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
