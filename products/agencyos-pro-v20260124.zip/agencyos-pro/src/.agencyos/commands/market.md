---
description: Market research
---

# Command: /market

> 🏯 **Binh Pháp**: 地形篇 (Địa Hình) - Market research

## Agent Tự Động Thực Hiện

Agent `researcher` sẽ tự động:

1. Market size
2. Trends
3. Segments
4. Report

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
