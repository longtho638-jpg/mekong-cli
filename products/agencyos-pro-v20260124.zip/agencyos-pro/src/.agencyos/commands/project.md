---
description: Setup project
---

# Command: /project

> 🏯 **Binh Pháp**: 計篇 (Kế) - Project setup

## Agent Tự Động Thực Hiện

Agent `project-manager` sẽ tự động:

1. Requirements
2. Timeline
3. Team

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
