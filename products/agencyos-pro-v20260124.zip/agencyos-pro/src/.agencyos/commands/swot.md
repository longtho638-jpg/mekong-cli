---
description: SWOT analysis
---

# Command: /swot

> 🏯 **Binh Pháp**: 計篇 (Kế) - SWOT analysis

## Agent Tự Động Thực Hiện

Agent `researcher` sẽ tự động:

1. Strengths
2. Weaknesses
3. Opportunities
4. Threats

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
