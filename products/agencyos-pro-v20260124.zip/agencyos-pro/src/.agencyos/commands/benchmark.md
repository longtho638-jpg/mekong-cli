---
description: Benchmark performance
---

# Command: /benchmark

> 🏯 **Binh Pháp**: 軍爭篇 (Quân Tranh) - Performance benchmark

## Agent Tự Động Thực Hiện

Agent `tester` sẽ tự động:

1. Run benchmarks
2. Compare results
3. Report

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
