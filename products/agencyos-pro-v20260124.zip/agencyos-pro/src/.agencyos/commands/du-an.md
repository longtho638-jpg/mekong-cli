---
description: Project management VN
---

# Command: /du-an

> 🏯 **Binh Pháp**: 始計篇 (Thủy Kế) - Quản lý dự án

## Agent Tự Động Thực Hiện

Agent `project-manager` sẽ tự động:

1. Setup
2. Timeline
3. Resources

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
