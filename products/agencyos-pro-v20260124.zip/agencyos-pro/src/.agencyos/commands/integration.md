---
description: Integrate external services
---

# Command: /integration

> 🏯 **Binh Pháp**: 用間篇 (Dụng Gián) - Third-party integration

## Agent Tự Động Thực Hiện

Agent `developer` sẽ tự động:

1. Research API
2. Implement connector
3. Error handling
4. Test

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
