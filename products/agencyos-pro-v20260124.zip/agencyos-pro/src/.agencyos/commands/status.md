---
description: Show status
---

# Command: /status

> 🏯 **Binh Pháp**: 計篇 (Kế) - Project status

## Agent Tự Động Thực Hiện

Agent `developer` sẽ tự động:

1. Git status
2. Build status
3. Health

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
