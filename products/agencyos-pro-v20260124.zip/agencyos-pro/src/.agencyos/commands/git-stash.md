---
description: Stash work
---

# Command: /git:stash

> 🏯 **Binh Pháp**: 九地篇 (Cửu Địa) - Stash changes

## Agent Tự Động Thực Hiện

Agent `git-manager` sẽ tự động:

1. Stash
2. List stashes
3. Apply

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
