---
description: Lint codebase
---

# Command: /lint

> 🏯 **Binh Pháp**: 法篇 (Pháp) - Code linting

## Agent Tự Động Thực Hiện

Agent `tester` sẽ tự động:

1. Run linters
2. Fix auto-fixable
3. Report issues

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
