---
description: Manage branches
---

# Command: /git:branch

> 🏯 **Binh Pháp**: 九變篇 (Cửu Biến) - Branch management

## Agent Tự Động Thực Hiện

Agent `git-manager` sẽ tự động:

1. Create/delete branches
2. Sync
3. Cleanup

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
