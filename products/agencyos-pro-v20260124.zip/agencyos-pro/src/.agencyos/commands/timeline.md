---
description: Create timeline
---

# Command: /timeline

> 🏯 **Binh Pháp**: 行軍篇 (Hành Quân) - Project timeline

## Agent Tự Động Thực Hiện

Agent `project-manager` sẽ tự động:

1. Milestones
2. Dependencies
3. Gantt

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
