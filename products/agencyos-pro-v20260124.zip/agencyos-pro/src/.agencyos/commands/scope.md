---
description: Define scope
---

# Command: /scope

> 🏯 **Binh Pháp**: 軍形篇 (Quân Hình) - Scope definition

## Agent Tự Động Thực Hiện

Agent `project-manager` sẽ tự động:

1. Features
2. Exclusions
3. Deliverables

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
