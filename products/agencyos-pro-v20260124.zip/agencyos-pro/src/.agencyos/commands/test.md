---
description: ⚡ Run tests locally and analyze the summary report.
---

Use the `tester` subagent to run tests locally and analyze the summary report.

**IMPORTANT**: **Do not** start implementing.
**IMPORTANT:** Analyze the skills catalog and activate the skills that are needed for the task during the process.