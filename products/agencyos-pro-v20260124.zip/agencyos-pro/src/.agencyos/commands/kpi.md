---
description: Define KPIs
---

# Command: /kpi

> 🏯 **Binh Pháp**: 計篇 (Kế) - KPI tracking

## Agent Tự Động Thực Hiện

Agent `planner` sẽ tự động:

1. Identify metrics
2. Set targets
3. Dashboard

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
