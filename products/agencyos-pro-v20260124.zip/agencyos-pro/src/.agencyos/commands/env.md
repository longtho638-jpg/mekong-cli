---
description: Setup environment
---

# Command: /env

> 🏯 **Binh Pháp**: 虛實篇 (Hư Thực) - Environment setup

## Agent Tự Động Thực Hiện

Agent `developer` sẽ tự động:

1. Check vars
2. Generate env
3. Validate

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
