---
description: Merge branches
---

# Command: /git:merge

> 🏯 **Binh Pháp**: 軍爭篇 (Quân Tranh) - Merge branches

## Agent Tự Động Thực Hiện

Agent `git-manager` sẽ tự động:

1. Check conflicts
2. Merge
3. Push

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
