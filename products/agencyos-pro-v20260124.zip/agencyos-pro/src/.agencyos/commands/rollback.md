---
description: Rollback deployment
---

# Command: /rollback

> 🏯 **Binh Pháp**: 九地篇 (Cửu Địa) - Emergency rollback

## Agent Tự Động Thực Hiện

Agent `developer` sẽ tự động:

1. Identify issue
2. Select version
3. Rollback
4. Verify

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
