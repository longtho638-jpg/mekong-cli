---
description: Create UI component
---

# Command: /component

> 🏯 **Binh Pháp**: 軍形篇 (Quân Hình) - UI component creation

## Agent Tự Động Thực Hiện

Agent `developer` sẽ tự động:

1. Analyze requirements
2. Generate component
3. Add styles
4. Test

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
