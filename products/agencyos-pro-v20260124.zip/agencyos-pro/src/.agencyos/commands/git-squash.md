---
description: Squash commits
---

# Command: /git:squash

> 🏯 **Binh Pháp**: 虛實篇 (Hư Thực) - Squash commits

## Agent Tự Động Thực Hiện

Agent `git-manager` sẽ tự động:

1. Interactive rebase
2. Squash
3. Push

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
