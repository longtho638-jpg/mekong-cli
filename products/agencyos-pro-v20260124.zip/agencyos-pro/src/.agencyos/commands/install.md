---
description: Install dependencies
---

# Command: /install

> 🏯 **Binh Pháp**: 地形篇 (Địa Hình) - Install project

## Agent Tự Động Thực Hiện

Agent `developer` sẽ tự động:

1. Read requirements
2. Install
3. Verify

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
