---
description: Goal setting
---

# Command: /muc-tieu

> 🏯 **Binh Pháp**: 勢篇 (Thế) - Thiết lập mục tiêu

## Agent Tự Động Thực Hiện

Agent `planner` sẽ tự động:

1. OKRs
2. KPIs
3. Tracking

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
