---
description: Clean build artifacts
---

# Command: /clean

> 🏯 **Binh Pháp**: 法篇 (Pháp) - Clean project

## Agent Tự Động Thực Hiện

Agent `developer` sẽ tự động:

1. Remove cache
2. Clean deps
3. Reset

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
