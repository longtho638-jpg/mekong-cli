---
description: User personas
---

# Command: /persona

> 🏯 **Binh Pháp**: 虛實篇 (Hư Thực) - Create personas

## Agent Tự Động Thực Hiện

Agent `researcher` sẽ tự động:

1. Research users
2. Create profiles
3. Document

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
