---
description: Update all deps
---

# Command: /update

> 🏯 **Binh Pháp**: 勢篇 (Thế) - Update dependencies

## Agent Tự Động Thực Hiện

Agent `developer` sẽ tự động:

1. Check updates
2. Update
3. Test

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
