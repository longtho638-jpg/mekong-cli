---
description: Design database schema
---

# Command: /schema

> 🏯 **Binh Pháp**: 軍形篇 (Quân Hình) - Schema design

## Agent Tự Động Thực Hiện

Agent `developer` sẽ tự động:

1. Analyze requirements
2. Design schema
3. Generate types
4. Document

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
