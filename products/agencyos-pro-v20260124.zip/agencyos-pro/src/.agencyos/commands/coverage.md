---
description: Analyze coverage
---

# Command: /coverage

> 🏯 **Binh Pháp**: 計篇 (Kế) - Coverage analysis

## Agent Tự Động Thực Hiện

Agent `tester` sẽ tự động:

1. Run coverage
2. Generate report
3. Identify gaps

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
