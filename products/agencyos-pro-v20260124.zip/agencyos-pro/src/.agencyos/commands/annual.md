---
description: Annual plan
---

# Command: /annual

> 🏯 **Binh Pháp**: 始計篇 (Thủy Kế) - Annual planning

## Agent Tự Động Thực Hiện

Agent `planner` sẽ tự động:

1. Review year
2. Set goals
3. Budget

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
