---
description: Run retro
---

# Command: /retro

> 🏯 **Binh Pháp**: 九變篇 (Cửu Biến) - Team retrospective

## Agent Tự Động Thực Hiện

Agent `planner` sẽ tự động:

1. What worked
2. Improvements
3. Action items

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
