---
description: Create roadmap
---

# Command: /roadmap

> 🏯 **Binh Pháp**: 始計篇 (Thủy Kế) - Product roadmap

## Agent Tự Động Thực Hiện

Agent `planner` sẽ tự động:

1. Goals
2. Milestones
3. Timeline
4. Dependencies

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
