---
description: Work schedule
---

# Command: /lich-trinh

> 🏯 **Binh Pháp**: 行軍篇 (Hành Quân) - Lịch trình công việc

## Agent Tự Động Thực Hiện

Agent `planner` sẽ tự động:

1. Tasks
2. Deadlines
3. Reminders

## Output

Agent tự generate - **ZERO USER INPUT REQUIRED**.

---

📖 [Related Commands](/docs/commands)
