"""
Backend Routes Package
"""

from .campaigns import router as campaigns_router

__all__ = ["campaigns_router"]
